public $endpoint_domain = 'https://fayupedia.id';
public $api_id = '34020';
public $api_key = 'mf1gv9-g4b3qb-mlquz9-w4kh4e-dt1spo';
